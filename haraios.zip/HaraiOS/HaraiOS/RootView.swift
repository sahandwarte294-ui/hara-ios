import SwiftUI

struct RootView: View {
    @State private var selectedTab: AppTab = .home

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(hex: 0x0A1020), Color(hex: 0x10172B), Color(hex: 0x0A1020)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            Group {
                switch selectedTab {
                case .home: HomeView()
                case .activity: ActivityView()
                case .settings: SettingsView()
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                BottomBar(selection: $selectedTab)
            }
        }
        .tint(Color(hex: 0x66E4D1))
    }
}

enum AppTab: String, CaseIterable {
    case home = "Home", activity = "Activity", settings = "Settings"
    var icon: String {
        switch self { case .home: "square.grid.2x2.fill"; case .activity: "waveform.path"; case .settings: "slider.horizontal.3" }
    }
}

struct BottomBar: View {
    @Binding var selection: AppTab
    var body: some View {
        HStack(spacing: 0) {
            ForEach(AppTab.allCases, id: \.self) { tab in
                Button { withAnimation(.snappy(duration: 0.22)) { selection = tab } } label: {
                    VStack(spacing: 5) {
                        Image(systemName: tab.icon).font(.system(size: 17, weight: .semibold))
                        Text(tab.rawValue).font(.system(size: 10, weight: .medium))
                    }
                    .foregroundStyle(selection == tab ? Color(hex: 0x72E6D4) : Color.white.opacity(0.46))
                    .frame(maxWidth: .infinity).padding(.top, 12).padding(.bottom, 5)
                }.buttonStyle(.plain)
            }
        }
        .background(.ultraThinMaterial)
        .overlay(alignment: .top) { Rectangle().fill(.white.opacity(0.08)).frame(height: 1) }
    }
}

extension SwiftUI.Color {
    init(hex: UInt, opacity: Double = 1) {
        self.init(.sRGB, red: Double((hex >> 16) & 0xff) / 255, green: Double((hex >> 8) & 0xff) / 255, blue: Double(hex & 0xff) / 255, opacity: opacity)
    }
}
