import SwiftUI

struct HomeView: View {
    @State private var showInfo = false
    private let columns = [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 26) {
                HStack(spacing: 11) {
                    Image("BrandMark").resizable().scaledToFill().frame(width: 42, height: 42).clipShape(RoundedRectangle(cornerRadius: 13))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("HaraiOS").font(.system(size: 19, weight: .bold, design: .rounded)).foregroundStyle(.white)
                        Text("TEST ENVIRONMENT").font(.system(size: 9, weight: .bold, design: .monospaced)).tracking(1.5).foregroundStyle(Color(hex: 0x72E6D4))
                    }
                    Spacer()
                    Button { showInfo = true } label: { Image(systemName: "info.circle").font(.system(size: 19)).foregroundStyle(.white.opacity(0.7)).frame(width: 42, height: 42).background(.white.opacity(0.06), in: Circle()) }
                }
                .padding(.top, 14)

                VStack(alignment: .leading, spacing: 14) {
                    HStack(spacing: 7) {
                        Circle().fill(Color(hex: 0x68E3BE)).frame(width: 7, height: 7).shadow(color: Color(hex: 0x68E3BE).opacity(0.8), radius: 6)
                        Text("SYSTEM OPERATIONAL").font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(1.3).foregroundStyle(Color(hex: 0x8BE8D3))
                    }
                    Text("Your space.\nYour system.").font(.system(size: 36, weight: .bold, design: .rounded)).tracking(-1.2).foregroundStyle(.white)
                    Text("A native iOS starter built for exploring, testing, and making things yours.")
                        .font(.system(size: 14)).foregroundStyle(.white.opacity(0.58)).lineSpacing(4).fixedSize(horizontal: false, vertical: true)
                    HStack(spacing: 8) {
                        Label("SwiftUI", systemImage: "swift"); Text("·"); Text("iOS 17+"); Text("·"); Text("Build 1.0")
                    }.font(.system(size: 10, weight: .medium, design: .monospaced)).foregroundStyle(.white.opacity(0.5)).padding(.top, 2)
                }
                .padding(22).frame(maxWidth: .infinity, alignment: .leading)
                .background {
                    RoundedRectangle(cornerRadius: 25).fill(LinearGradient(colors: [Color(hex: 0x1A2B3A), Color(hex: 0x171E32), Color(hex: 0x20223B)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    RoundedRectangle(cornerRadius: 25).stroke(.white.opacity(0.09), lineWidth: 1)
                    Circle().fill(Color(hex: 0x6BE5D1, opacity: 0.12)).frame(width: 150).blur(radius: 40).offset(x: 120, y: -70).frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing).clipped()
                }

                VStack(alignment: .leading, spacing: 14) {
                    HStack { Text("Explore your tools").font(.system(size: 18, weight: .bold, design: .rounded)).foregroundStyle(.white); Spacer(); Text("04 MODULES").font(.system(size: 9, weight: .semibold, design: .monospaced)).tracking(1).foregroundStyle(.white.opacity(0.4)) }
                    LazyVGrid(columns: columns, spacing: 12) {
                        ToolCard(title: "Workspace", subtitle: "Your personal hub", icon: "square.grid.2x2", color: 0x6BE5D1)
                        ToolCard(title: "Insights", subtitle: "See what’s new", icon: "chart.xyaxis.line", color: 0xA996FF)
                        ToolCard(title: "Connections", subtitle: "Linked services", icon: "point.3.connected.trianglepath.dotted", color: 0xFFBC78)
                        ToolCard(title: "Preferences", subtitle: "Make it yours", icon: "slider.horizontal.3", color: 0x7DB6FF)
                    }
                }
                HStack(spacing: 12) {
                    Image(systemName: "sparkles").foregroundStyle(Color(hex: 0x83E7D7))
                    VStack(alignment: .leading, spacing: 3) { Text("Ready for your next idea?").font(.system(size: 13, weight: .semibold)).foregroundStyle(.white); Text("This starter is yours to customize.").font(.system(size: 11)).foregroundStyle(.white.opacity(0.52)) }
                    Spacer()
                    Image(systemName: "arrow.up.right").font(.system(size: 12, weight: .bold)).foregroundStyle(.white.opacity(0.6))
                }.padding(15).background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 16)).overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.06), lineWidth: 1))
                Text("HARAIOS  •  MADE TO EXPLORE").font(.system(size: 9, weight: .medium, design: .monospaced)).tracking(1.4).foregroundStyle(.white.opacity(0.28)).frame(maxWidth: .infinity).padding(.bottom, 12)
            }.padding(.horizontal, 20)
        }
        .alert("About HaraiOS", isPresented: $showInfo) { Button("Got it", role: .cancel) {} } message: { Text("A SwiftUI sample app for testing. Customize the views, colors, and app icon in Xcode.") }
    }
}

private struct ToolCard: View {
    let title: String; let subtitle: String; let icon: String; let color: UInt
    @State private var tapped = false
    var body: some View {
        Button { withAnimation(.spring(response: 0.3, dampingFraction: 0.65)) { tapped.toggle() } } label: {
            VStack(alignment: .leading, spacing: 15) {
                Image(systemName: tapped ? "checkmark" : icon).font(.system(size: 17, weight: .semibold)).foregroundStyle(Color(hex: color)).frame(width: 38, height: 38).background(Color(hex: color, opacity: 0.12), in: RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 4) { Text(title).font(.system(size: 13, weight: .semibold)).foregroundStyle(.white); Text(tapped ? "Opened for testing" : subtitle).font(.system(size: 10)).foregroundStyle(.white.opacity(0.48)).lineLimit(1) }
            }.frame(maxWidth: .infinity, minHeight: 112, alignment: .leading).padding(14).background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 18)).overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.07), lineWidth: 1))
        }.buttonStyle(.plain).scaleEffect(tapped ? 0.97 : 1)
    }
}
