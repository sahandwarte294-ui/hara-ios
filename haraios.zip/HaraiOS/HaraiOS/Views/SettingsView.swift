import SwiftUI

struct SettingsView: View {
    @State private var notifications = true
    @State private var haptics = true
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 23) {
                PageHeading(kicker: "MAKE IT YOURS", title: "Settings", detail: "A few switches to try out.")
                VStack(spacing: 0) {
                    ToggleRow(title: "Notifications", subtitle: "Sample local preferences", icon: "bell.badge", value: $notifications)
                    Divider().overlay(.white.opacity(0.07)).padding(.leading, 56)
                    ToggleRow(title: "Haptic feedback", subtitle: "Touch response preview", icon: "hand.tap", value: $haptics)
                }.padding(.horizontal, 16).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20)).overlay(RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.06), lineWidth: 1))
                VStack(alignment: .leading, spacing: 12) {
                    Text("ABOUT THIS BUILD").font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(1.4).foregroundStyle(.white.opacity(0.4))
                    InfoRow(label: "Version", value: "1.0.0 (1)")
                    InfoRow(label: "Platform", value: "iOS 17+")
                    InfoRow(label: "Framework", value: "SwiftUI")
                    InfoRow(label: "Mode", value: "Local demo")
                }.padding(18).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20)).overlay(RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.06), lineWidth: 1))
                HStack { Spacer(); VStack(spacing: 8) { Image("BrandMark").resizable().frame(width: 48, height: 48).clipShape(RoundedRectangle(cornerRadius: 15)); Text("HaraiOS").font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.65)); Text("A small space to explore.").font(.system(size: 11)).foregroundStyle(.white.opacity(0.38)) }; Spacer() }.padding(.vertical, 16)
            }.padding(20).padding(.top, 14)
        }
    }
}

private struct ToggleRow: View {
    let title: String; let subtitle: String; let icon: String; @Binding var value: Bool
    var body: some View {
        HStack(spacing: 13) {
            Image(systemName: icon).font(.system(size: 15, weight: .medium)).foregroundStyle(Color(hex: 0x73E1D1)).frame(width: 36, height: 36).background(Color(hex: 0x73E1D1, opacity: 0.11), in: RoundedRectangle(cornerRadius: 11))
            VStack(alignment: .leading, spacing: 3) { Text(title).font(.system(size: 13, weight: .semibold)).foregroundStyle(.white); Text(subtitle).font(.system(size: 10)).foregroundStyle(.white.opacity(0.45)) }
            Spacer(); Toggle(title, isOn: $value).labelsHidden().scaleEffect(0.82, anchor: .trailing)
        }.padding(.vertical, 13)
    }
}

private struct InfoRow: View {
    let label: String; let value: String
    var body: some View { HStack { Text(label).font(.system(size: 12)).foregroundStyle(.white.opacity(0.5)); Spacer(); Text(value).font(.system(size: 12, weight: .medium, design: .monospaced)).foregroundStyle(.white.opacity(0.82)) } }
}

struct PageHeading: View {
    let kicker: String; let title: String; let detail: String
    var body: some View { VStack(alignment: .leading, spacing: 8) { Text(kicker).font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(1.5).foregroundStyle(Color(hex: 0x72E6D4)); Text(title).font(.system(size: 32, weight: .bold, design: .rounded)).tracking(-0.8).foregroundStyle(.white); Text(detail).font(.system(size: 13)).foregroundStyle(.white.opacity(0.52)) } }
}
