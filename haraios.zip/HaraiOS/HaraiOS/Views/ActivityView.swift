import SwiftUI

struct ActivityView: View {
    private let events: [(String, String, String, UInt)] = [
        ("App initialized", "HaraiOS is ready to explore", "JUST NOW", 0x68E3BE),
        ("Workspace created", "Your test environment is set up", "TODAY", 0xA996FF),
        ("System check", "All local modules are available", "TODAY", 0x7DB6FF)
    ]
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                PageHeading(kicker: "YOUR TIMELINE", title: "Activity", detail: "A little history of what’s happening.")
                VStack(spacing: 0) {
                    ForEach(Array(events.enumerated()), id: \.offset) { index, event in
                        HStack(alignment: .top, spacing: 14) {
                            VStack(spacing: 0) { Circle().fill(Color(hex: event.3)).frame(width: 10, height: 10).padding(.top, 4); if index < events.count - 1 { Rectangle().fill(.white.opacity(0.08)).frame(width: 1).frame(maxHeight: .infinity).padding(.top, 7) } }.frame(width: 12)
                            VStack(alignment: .leading, spacing: 5) { HStack { Text(event.0).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white); Spacer(); Text(event.2).font(.system(size: 9, weight: .medium, design: .monospaced)).foregroundStyle(.white.opacity(0.38)) }; Text(event.1).font(.system(size: 12)).foregroundStyle(.white.opacity(0.53)) }
                                .padding(.bottom, 24)
                        }
                    }
                }.padding(18).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20)).overlay(RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.06), lineWidth: 1))
                Text("Everything here stays on this device. No account or network required.").font(.system(size: 12)).foregroundStyle(.white.opacity(0.45)).padding(.horizontal, 4)
            }.padding(20).padding(.top, 14)
        }
    }
}
