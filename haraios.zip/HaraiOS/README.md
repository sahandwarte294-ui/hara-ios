# HaraiOS — SwiftUI iOS Test Project

A small, self-contained native iOS starter app built with SwiftUI. It includes a custom HaraiOS app icon and brand mark, a dark dashboard, a three-tab layout, tappable demo cards, an activity timeline, and local settings toggles. It uses no external packages, server, account, or API.

## Open in Xcode

1. Unzip the archive on a Mac with Xcode 15 or newer.
2. Open `HaraiOS.xcodeproj`.
3. Choose the `HaraiOS` scheme and an iPhone simulator (or a connected iPhone).
4. Press **Run**. For a physical device, select your Apple development team under **Signing & Capabilities** if Xcode asks.

Minimum deployment target: iOS 17. Bundle identifier: `com.harais.testapp` (change it in Xcode if needed).

## Project map

- `HaraiOS/HaraiOSApp.swift` — app entry point.
- `HaraiOS/RootView.swift` — navigation, theme, and shared components.
- `HaraiOS/Views/` — dashboard, activity, and settings screens.
- `HaraiOS/Assets.xcassets/` — app icon and in-app brand mark.

This is a starter/demo project, not a production service. All sample content is local and illustrative.
